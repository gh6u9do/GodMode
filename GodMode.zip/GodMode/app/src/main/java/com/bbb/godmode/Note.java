package com.bbb.godmode;

public class Note {
    String text;
    Note(String text){
        this.text = text;
    }
}
