package com.bbb.godmode;

import java.util.ArrayList;

public class DataSet {
    // Использую как глобальные переменные
    public static ArrayList<Task> items = new ArrayList<Task>();
    public static ArrayList<Note> notes = new ArrayList<Note>();
}
